#include <iostream>
#include <cmath>
#include <stdexcept>
#include <sstream>

class Calculator {
public:
    double add(double a, double b) {
        return a + b;
    }

    double subtract(double a, double b) {
        return a - b;
    }

    double multiply(double a, double b) {
        return a * b;
    }

    double divide(double a, double b) {
        if (b == 0) {
            throw std::runtime_error("Division by zero");
        }
        return a / b;
    }

    double sin(double angle) {
        return std::sin(angle);
    }

    double cos(double angle) {
        return std::cos(angle);
    }

    double tan(double angle) {
        return std::tan(angle);
    }

    double log(double base, double value) {
        if (base <= 0 || value <= 0) {
            throw std::invalid_argument("Invalid input for logarithm");
        }
        return std::log(value) / std::log(base);
    }
};
using namespace std;
int main() {
    Calculator calculator;

    cout << "Scientific Calculator" << endl;

    while (true) {
        cout << "Enter operation (e.g., 'add 2 3' or 'sin 30'): ";
        string input;
        getline(cin, input);

        if (input == "exit") {
            break;
        }

        istringstream iss(input);
        string operation;
        iss >> operation;

        try {
            if (operation == "add" || operation == "subtract" || operation == "multiply" || operation == "divide") {
                double a, b;
                iss >> a >> b;

                if (operation == "add") {
                   cout << "Result: " << calculator.add(a, b) << endl;
                   
                } else if (operation == "subtract") {
                   cout << "Result: " << calculator.subtract(a, b) << endl;
                } else if (operation == "multiply") {
                    cout << "Result: " << calculator.multiply(a, b) << endl;
                } else if (operation == "divide") {
                    cout << "Result: " << calculator.divide(a, b) << endl;
                }
            } else if (operation == "sin" || operation == "cos" || operation == "tan") {
                double angle;
                iss >> angle;

                if (operation == "sin") {
                    cout << "Result: " << calculator.sin(angle) << endl;
                } else if (operation == "cos") {
                  cout << "Result: " << calculator.cos(angle) << endl;
                } else if (operation == "tan") {
                    cout << "Result: " << calculator.tan(angle) << endl;
                }
            } else if (operation == "log") {
                double base, value;
                iss >> base >> value;

                cout << "Result: " << calculator.log(base, value) << endl;
            } else {
               cout << "Invalid operation. Please try again." << endl;
            }
        } catch (const exception & e) {
            cerr << "Error: " << e.what() << endl;
        }
    }

    return 0;
}

